export function getSaludo(req, res) {
  //res.send('Hola mundo');
  
  res.json({ message: 'Hola mundo' });
}
