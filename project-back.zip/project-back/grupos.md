# rol - modulo - rol_modulo
zambrano - herrera - arico

# usuario 
chanatzaxi - colina

# acciones 
carrillo - alomia

# login - cerrar sesion 
paredes - ortiz 

# producto 
cortez - villacrez

# categoria
pincha - quinga

# ventas - factura
james - yanez - collaguazo

# dashboard
gualotuña - vieria

# pizzas
lechon - herrera

